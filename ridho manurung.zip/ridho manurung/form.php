<form action="insert.php" method="post">
Nim : <br>
<input type="text" name="nim">
<br>
Nama : <br>
<input type="text" name="nama" >
<br>
Alamat : <br>
<textarea name="alamat" cols="30" rows="10"></textarea>
<br>
Jenis Kelamin : <br>
<select name="jenis_kelamin">
<option value="PRIA">PRIA</option>
<option value="WANITA">WANITA</option>
</select>
<br>
Agama : <br>
<select name="agama">
<option value="ISLAM">ISLAM</option>
<option value="KRISTEN">KRISTEN</option>
</select>
<br>
Email : <br>
<input type="text" name="email" >
<br>
Password: <br>
<input type="password" name="password" >
<br>
<br>
<button type="submit">Simpan Mahasiawa</button>
</form>
