<?php 
    $koneksi = mysqli_connect('localhost', 'root', '', 'db_perpustakaan')
     or die('Database tidak di temukan');
    //  die digunakan untu k menampilkan pesan jika program tidak berjalan / error
?>